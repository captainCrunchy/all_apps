'''
DESCRIPTION
example of graphviz

RUN
python family_tree_graphviz_1.py

RESULT
family_tree_graphviz_1.png

'''
from graphviz import Digraph

dot = Digraph(comment='My Family Tree')

# Add nodes for individuals
dot.node('A', 'Grandfather John', shape='box')
dot.node('B', 'Grandmother Mary', shape='box')
dot.node('C', 'Father David', shape='box')
dot.node('D', 'Mother Sarah', shape='box')
dot.node('E', 'Child Emily', shape='box')

# Add edges to represent relationships
dot.edge('A', 'C', label='parent_of')
dot.edge('B', 'C', label='parent_of')
dot.edge('C', 'E', label='parent_of')
dot.edge('D', 'E', label='parent_of')
dot.edge('C', 'D', label='spouse_of', dir='none') # Undirected edge for spouse relationship

# Render the graph
dot.render('family_tree_graphviz_1', view=True, format='png')