"""
Attach to an existing Chrome instance via Selenium.

COMMANDS
10/12/2025
generate code in python using selenium that will attach to a running instance of google chrome, make sure it works, use current open terminal of command prompt for any requred executions, my python virtual environment is already activated
GPT-5 Codex (Preview)

INSTALL
pip install selenium

RUN
"C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 --user-data-dir=C:\Temp\ChromeDebugTemp

python py_attach.py

"""

from __future__ import annotations

import argparse
import sys
from typing import Optional

from selenium import webdriver
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.chrome.options import Options


def build_driver(debug_address: str) -> webdriver.Chrome:
	"""Return a Selenium WebDriver bound to an existing Chrome instance."""
	chrome_options = Options()
	chrome_options.debugger_address = debug_address
	return webdriver.Chrome(options=chrome_options)


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
	parser = argparse.ArgumentParser(
		description=(
			"Attach to a Chrome instance started with '--remote-debugging-port'"
		)
	)
	parser.add_argument(
		"--host",
		default="127.0.0.1",
		help="Hostname or IP where Chrome exposes the debugging port",
	)
	parser.add_argument(
		"--port",
		type=int,
		default=9222,
		help="Remote debugging port Chrome was started with",
	)
	return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
	args = parse_args(argv)
	debugger_address = f"{args.host}:{args.port}"

	try:
		driver = build_driver(debugger_address)
	except WebDriverException as exc:  # pragma: no cover - diagnostic output only
		msg = (
			"Failed to connect to Chrome. Ensure Chrome is running with "
			"'--remote-debugging-port={port}' on host {host}. Original error: {exc}"
		).format(port=args.port, host=args.host, exc=exc)
		print(msg, file=sys.stderr)
		return 1

	print("Connected to Chrome at", debugger_address)
	print("Current page title:", driver.title)
	return 0


if __name__ == "__main__":
    raise SystemExit(main())